#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from .main import main

__version__ = "1.0.2"
