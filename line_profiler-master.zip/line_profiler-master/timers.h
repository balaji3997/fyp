#include "Python.h"

PY_LONG_LONG hpTimer(void);
double hpTimerUnit(void);
